# MyCRM Installation (Debian 12)

## Schritte:
1. `unzip mycrm.zip && cd mycrm`
2. `bash setup.sh`
3. Browser öffnen: `http://<deine-ip>:8000/`
4. Login: `alfred` / `ddcm9677`